import { getTenantFromSession } from "@/lib/tenant-context";
import { apiRateLimit } from "@/lib/rate-limit";
import { apiError, apiSuccess } from "@/lib/utils";
import { db } from "@/lib/db";
import { appointments, customers, staff, users } from "@/lib/db/schema";
import { and, eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { tenantId } = await getTenantFromSession();
    const { success } = await apiRateLimit.limit(tenantId);
    if (!success) return apiError("Too many requests", "RATE_LIMITED", 429);

    const list = await db.select()
      .from(appointments)
      .innerJoin(customers, eq(appointments.customerId, customers.id))
      .leftJoin(staff, eq(appointments.staffId, staff.id))
      .leftJoin(users, eq(staff.userId, users.id))
      .where(eq(appointments.tenantId, tenantId));

    const mapped = list.map(item => ({
      id: item.appointments.id,
      startTime: item.appointments.startTime,
      endTime: item.appointments.endTime,
      status: item.appointments.status,
      customer: item.customers,
      staff: item.staff ? { id: item.staff.id, user: item.users } : null
    }));

    return apiSuccess(mapped);
  } catch (err: any) {
    return apiError("Internal error", "INTERNAL_ERROR", 500);
  }
}

export async function POST(req: Request) {
  try {
    const { tenantId, userId } = await getTenantFromSession();
    const { success } = await apiRateLimit.limit(tenantId);
    if (!success) return apiError("Too many requests", "RATE_LIMITED", 429);

    const body = await req.json();

    const [inserted] = await db.insert(appointments).values({
      tenantId,
      branchId: body.branchId,
      customerId: body.customerId,
      staffId: body.staffId || null,
      startTime: new Date(body.startTime),
      endTime: new Date(new Date(body.startTime).getTime() + 30 * 60000), // Default 30 mins
      status: "scheduled",
      type: body.type || "booking",
      createdBy: userId
    }).returning();

    return apiSuccess(inserted);
  } catch (err: any) {
    return apiError("Internal error", "INTERNAL_ERROR", 500);
  }
}

"use client";
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function SettingsGeneralPage() {
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = data.get("name") as string;
    const phone = data.get("phone") as string;

    try {
      const res = await fetch("/api/tenant/settings/general", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone }),
      });
      if (!res.ok) throw new Error();
      toast.success("Salon configurations updated successfully!");
    } catch {
      toast.error("Failed to update general settings.");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">General Settings</h2>
        <p className="text-sm text-muted-foreground">Configure business metadata and invoices templates.</p>
      </div>

      <Card className="max-w-xl">
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Salon Business Name</Label>
              <Input name="name" required defaultValue="Your Premium Salon" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Support Line</Label>
              <Input name="phone" defaultValue="+91 98765 43210" />
            </div>
            <Button type="submit">Save Configurations</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

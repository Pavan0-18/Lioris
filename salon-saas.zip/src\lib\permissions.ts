export const ROLES = ["OWNER", "MANAGER", "RECEPTIONIST", "STYLIST"] as const;
export type Role = typeof ROLES[number];

export const PERMISSIONS = {
  // Appointments
  "appointments:read":   ["OWNER", "MANAGER", "RECEPTIONIST", "STYLIST"],
  "appointments:create": ["OWNER", "MANAGER", "RECEPTIONIST"],
  "appointments:update": ["OWNER", "MANAGER", "RECEPTIONIST"],
  "appointments:delete": ["OWNER", "MANAGER"],
  // Staff
  "staff:read":          ["OWNER", "MANAGER"],
  "staff:create":        ["OWNER"],
  "staff:update":        ["OWNER"],
  "staff:deactivate":    ["OWNER"],
  // Attendance
  "attendance:mark":     ["OWNER", "MANAGER", "RECEPTIONIST"],
  "attendance:self":     ["STYLIST"],
  // Payroll
  "payroll:read":        ["OWNER", "MANAGER"],
  "payroll:approve":     ["OWNER"],
  // Billing
  "billing:read":        ["OWNER", "MANAGER", "RECEPTIONIST"],
  "billing:create":      ["OWNER", "MANAGER", "RECEPTIONIST"],
  "billing:void":        ["OWNER", "MANAGER"],
  // CRM
  "customers:read":      ["OWNER", "MANAGER", "RECEPTIONIST"],
  "customers:create":    ["OWNER", "MANAGER", "RECEPTIONIST"],
  "customers:update":    ["OWNER", "MANAGER", "RECEPTIONIST"],
  // Settings
  "settings:general":    ["OWNER"],
  "settings:branches":   ["OWNER", "MANAGER"],
  "settings:services":   ["OWNER", "MANAGER"],
  "settings:team":       ["OWNER"],
  "settings:billing":    ["OWNER"],
  // Reports
  "reports:read":        ["OWNER", "MANAGER"],
} as const;

export type Permission = keyof typeof PERMISSIONS;

export function can(role: Role, permission: Permission): boolean {
  return (PERMISSIONS[permission] as readonly string[]).includes(role);
}

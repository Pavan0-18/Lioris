"use client";
import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";

export default function SuperadminTenantsPage() {
  const router = useRouter();
  const { data: tenantsData } = useQuery({
    queryKey: ["superadmin-tenants"],
    queryFn: () => fetch("/api/superadmin/tenants").then(res => res.json())
  });

  const list = tenantsData?.data || [];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Administrative Tenants Control</h2>
        <p className="text-sm text-muted-foreground">Deploy, activate, or suspend multi-tenant salon workspaces.</p>
      </div>

      <div className="border border-border rounded-lg overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Salon Name</TableHead>
              <TableHead>Email Domain</TableHead>
              <TableHead>Trial End Date</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {list.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-10 text-xs text-muted-foreground">
                  No registered tenants on platform.
                </TableCell>
              </TableRow>
            ) : (
              list.map((t: any) => (
                <TableRow key={t.id} className="cursor-pointer" onClick={() => router.push(`/superadmin/tenants/${t.id}`)}>
                  <TableCell className="font-semibold text-sm">{t.name}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{t.email}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {new Date(t.trialEndsAt).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                    <Button variant="outline" size="sm" onClick={() => router.push(`/superadmin/tenants/${t.id}`)}>
                      Manage Features
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

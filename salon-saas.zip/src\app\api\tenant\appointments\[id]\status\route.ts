import { getTenantFromSession } from "@/lib/tenant-context";
import { apiError, apiSuccess } from "@/lib/utils";
import { db } from "@/lib/db";
import { appointments, invoices } from "@/lib/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request, { params }: { params: any }) {
  try {
    const { id } = await params;
    const { tenantId, userId } = await getTenantFromSession();
    const body = await req.json();

    const [updated] = await db.update(appointments)
      .set({ status: body.status, updatedAt: new Date() })
      .where(eq(appointments.id, id))
      .returning();

    // Auto-create invoice if completed
    if (body.status === "completed") {
      await db.insert(invoices).values({
        tenantId,
        branchId: updated.branchId,
        customerId: updated.customerId,
        appointmentId: updated.id,
        invoiceNo: `INV-${Date.now().toString().slice(-6)}`,
        subtotal: 25.00,
        total: 25.00,
        currency: "USD",
        status: "draft",
        createdBy: userId
      });
    }

    return apiSuccess(updated);
  } catch (err: any) {
    return apiError("Internal error", "INTERNAL_ERROR", 500);
  }
}

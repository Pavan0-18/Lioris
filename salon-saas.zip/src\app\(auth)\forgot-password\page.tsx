"use client";
import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import Link from "next/link";

export default function ForgotPasswordPage() {
  const [sent, setSent] = React.useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const email = data.get("email") as string;

    if (!email) return;
    try {
      await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      setSent(true);
      toast.success("Security token sent to email address!");
    } catch {
      toast.error("Failed to generate security token.");
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-bold text-slate-100">Reset Security Password</h2>
        <p className="text-xs text-slate-400">We will dispatch an absolute security reset link.</p>
      </div>

      {sent ? (
        <div className="space-y-3 text-center">
          <p className="text-xs text-green-400 font-medium">Reset instructions have been sent successfully.</p>
          <Link href="/login">
            <Button className="w-full mt-2 text-xs">Back to Login</Button>
          </Link>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="space-y-1.5">
            <Label className="text-slate-200">Email Address</Label>
            <Input
              name="email"
              type="email"
              placeholder="owner@salonsaas.com"
              className="bg-slate-800 border-slate-700 text-slate-100"
              required
            />
          </div>
          <Button type="submit" className="w-full bg-teal-500 text-slate-950 font-bold">
            Send Password Reset Link
          </Button>
        </form>
      )}
    </div>
  );
}

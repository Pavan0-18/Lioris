import { headers } from "next/headers";
import { db } from "@/lib/db";
import { tenants } from "@/lib/db/schema";
import { eq } from "drizzle-orm";

export interface TenantContext {
  tenantId: string;
  userId: string;
  role: string;
  tenant: typeof tenants.$inferSelect;
}

export async function getTenantFromSession(): Promise<TenantContext> {
  const headersList = await headers();
  const tenantId = headersList.get("x-tenant-id");
  const userId = headersList.get("x-user-id");
  const role = headersList.get("x-user-role");

  if (!tenantId || !userId) {
    const err = new Error("No tenant session");
    (err as any).code = "UNAUTHORIZED";
    (err as any).status = 401;
    throw err;
  }

  const tenant = await db.query.tenants.findFirst({
    where: eq(tenants.id, tenantId),
  });

  if (!tenant) {
    const err = new Error("Tenant not found");
    (err as any).code = "NOT_FOUND";
    (err as any).status = 404;
    throw err;
  }

  if (!tenant.isActive || tenant.planStatus === "suspended") {
    const err = new Error("Account suspended or inactive");
    (err as any).code = "FORBIDDEN";
    (err as any).status = 403;
    throw err;
  }

  return { tenantId, userId, role: role ?? "RECEPTIONIST", tenant };
}

import { db } from "@/lib/db";
import { auditLogs } from "@/lib/db/schema";

export async function logAction(
  tenantId: string,
  userId: string,
  action: "CREATE" | "UPDATE" | "DELETE",
  entityType: string,
  entityId: string,
  changes?: Record<string, unknown>,
): Promise<void> {
  try {
    await db.insert(auditLogs).values({
      tenantId,
      userId,
      action,
      entityType,
      entityId,
      changes: changes ? JSON.stringify(changes) : null,
    });
  } catch (err) {
    console.error("Audit log error:", err);
  }
}

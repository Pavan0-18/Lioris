import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";

export async function middleware(req: NextRequest) {
  const session = await auth();
  const path = req.nextUrl.pathname;

  // Super admin panel protection
  if (path.startsWith("/superadmin") || path.startsWith("/api/superadmin")) {
    if (!session?.user || session.user.role !== "SUPER_ADMIN") {
      if (path.startsWith("/api/")) {
        return Response.json({ error: "Forbidden", code: "FORBIDDEN" }, { status: 403 });
      }
      return NextResponse.redirect(new URL("/login?type=superadmin", req.url));
    }
    return NextResponse.next();
  }

  // Tenant dashboard protection
  if (path.startsWith("/dashboard") || path.startsWith("/api/tenant")) {
    if (!session?.user || !session.user.tenantId) {
      if (path.startsWith("/api/")) {
        return Response.json({ error: "Unauthorized", code: "UNAUTHORIZED" }, { status: 401 });
      }
      return NextResponse.redirect(new URL("/login", req.url));
    }
    // Inject tenant context into headers for API routes
    const res = NextResponse.next();
    res.headers.set("x-tenant-id", session.user.tenantId);
    res.headers.set("x-user-id", session.user.id ?? "");
    res.headers.set("x-user-role", session.user.role ?? "");
    return res;
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/superadmin/:path*",
    "/api/tenant/:path*",
    "/api/superadmin/:path*",
  ],
};

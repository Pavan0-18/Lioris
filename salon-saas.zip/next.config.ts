import { withSentryConfig } from "@sentry/nextjs";
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverComponentsExternalPackages: ["bcryptjs"],
  },
};

export default withSentryConfig(nextConfig, {
  silent: true,
  org: "salon-saas",
  project: "salon-saas",
});

import React from "react";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { db } from "@/lib/db";
import { appointments, customers, invoices } from "@/lib/db/schema";
import { eq, and } from "drizzle-orm";
import { Calendar, DollarSign, UserCheck, Users } from "lucide-react";

export default async function TenantDashboardPage() {
  const session = await auth();
  if (!session || !session.user) redirect("/login");
  const tenantId = session.user.tenantId || "";

  // Query statistics
  const apptsList = await db.select().from(appointments).where(eq(appointments.tenantId, tenantId));
  const paidInvoices = await db.select({ total: invoices.total }).from(invoices).where(and(eq(invoices.tenantId, tenantId), eq(invoices.status, "paid")));
  const customersList = await db.select().from(customers).where(eq(customers.tenantId, tenantId));

  const totalRevenue = paidInvoices.reduce((sum, item) => sum + item.total, 0);

  const stats = [
    { label: "Today's Appointments", value: apptsList.length, icon: Calendar },
    { label: "Total Paid Revenue", value: `$${totalRevenue.toFixed(2)}`, icon: DollarSign },
    { label: "Active Customers", value: customersList.length, icon: UserCheck },
    { label: "On-Duty Stylists", value: 3, icon: Users },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard Overview</h1>
        <p className="text-sm text-muted-foreground">Monitor performance, stylist schedules, and revenue.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.label}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid gap-4 md:grid-cols-1 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Calendar Allocations</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Customer Name</TableHead>
                  <TableHead>Stylist</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Schedule</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {apptsList.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-6 text-xs text-muted-foreground">
                      No appointments booked yet.
                    </TableCell>
                  </TableRow>
                ) : (
                  apptsList.slice(0, 10).map((appt) => (
                    <TableRow key={appt.id}>
                      <TableCell className="font-semibold text-sm">John Doe</TableCell>
                      <TableCell className="text-xs text-muted-foreground">Stylist Stylist</TableCell>
                      <TableCell>
                        <Badge variant="outline">{appt.status.toUpperCase()}</Badge>
                      </TableCell>
                      <TableCell className="text-right text-xs">
                        {new Date(appt.startTime).toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

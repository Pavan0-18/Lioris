"use client";
import React from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const type = searchParams.get("type") || "tenant";
  const [submitting, setSubmitting] = React.useState(false);

  const { register, handleSubmit } = useForm({
    defaultValues: { email: "", password: "" }
  });

  const onSubmit = async (data: any) => {
    setSubmitting(true);
    try {
      const res = await signIn("credentials", {
        redirect: false,
        email: data.email,
        password: data.password,
        type
      });

      if (res?.error) {
        toast.error("Invalid credentials entered.");
      } else {
        toast.success("Workspace loaded successfully!");
        router.refresh();
      }
    } catch {
      toast.error("Network interface error occurred.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-bold">
          {type === "superadmin" ? "Platform Administrator Login" : "Workspace Member Login"}
        </h2>
        <p className="text-xs text-slate-400">Please enter your credentials to authenticate.</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
        <div className="space-y-1.5">
          <Label className="text-slate-200">Email Address</Label>
          <Input
            type="email"
            {...register("email")}
            placeholder="member@salonsaas.com"
            className="bg-slate-800 border-slate-700 text-slate-100 focus-visible:ring-teal-400"
            required
          />
        </div>

        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <Label className="text-slate-200">Security Password</Label>
            <Link href="/forgot-password" className="text-xs text-teal-400 hover:underline">Forgot password?</Link>
          </div>
          <Input
            type="password"
            {...register("password")}
            placeholder="••••••••"
            className="bg-slate-800 border-slate-700 text-slate-100 focus-visible:ring-teal-400"
            required
          />
        </div>

        <Button type="submit" disabled={submitting} className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold">
          {submitting ? "Authenticating..." : "Sign In to Workspace"}
        </Button>
      </form>

      {type !== "superadmin" && (
        <div className="text-center pt-2 border-t border-slate-800">
          <p className="text-xs text-slate-400">
            Don't have a salon workspace?{" "}
            <Link href="/signup" className="text-teal-400 font-semibold hover:underline">Create Salon SaaS Account</Link>
          </p>
        </div>
      )}
    </div>
  );
}

"use client";
import React from "react";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function SuperadminTenantDetailPage() {
  const { id } = useParams();

  const { data: tenantData, refetch } = useQuery({
    queryKey: ["superadmin-tenant-detail", id],
    queryFn: () => fetch(`/api/superadmin/tenants/${id}`).then(res => res.json())
  });

  const tenant = tenantData?.data;

  if (!tenant) {
    return <div className="py-20 text-center text-sm text-muted-foreground">Loading workspace administration details...</div>;
  }

  const handleToggleFeature = async (featureId: string, isEnabled: boolean) => {
    try {
      const res = await fetch(`/api/superadmin/tenants/${id}/features`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify([{ featureId, isEnabled }]),
      });
      if (!res.ok) throw new Error();
      toast.success("Feature flag synchronized!");
      refetch();
    } catch {
      toast.error("Failed to update feature flag.");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">{tenant.name}</h2>
        <p className="text-sm text-muted-foreground">Workspace administrative control and feature flags mappings.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 max-w-4xl">
        <Card>
          <CardHeader>
            <CardTitle>System Feature Flags Control</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {tenant.featuresList?.map((f: any) => (
              <div key={f.id} className="flex items-center justify-between py-2 border-b last:border-0 border-border">
                <div>
                  <span className="font-semibold text-xs">{f.name}</span>
                  <span className="text-[10px] block text-muted-foreground font-mono">{f.key}</span>
                </div>
                <Switch
                  checked={f.isEnabled}
                  onCheckedChange={(val) => handleToggleFeature(f.id, val)}
                />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

import React from "react";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { TenantSidebar } from "@/components/layouts/tenant-sidebar";
import { db } from "@/lib/db";
import { tenants } from "@/lib/db/schema";
import { eq } from "drizzle-orm";

export default async function TenantLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session || !session.user) redirect("/login");

  // Query onboarding status
  const [tenant] = await db.select({ onboardingDone: tenants.onboardingDone })
    .from(tenants)
    .where(eq(tenants.id, session.user.tenantId || ""))
    .limit(1);

  if (tenant && !tenant.onboardingDone) {
    redirect("/dashboard/setup");
  }

  return (
    <div className="flex h-screen">
      <TenantSidebar />
      <main className="flex-1 overflow-y-auto bg-slate-50 p-6">
        {children}
      </main>
    </div>
  );
}

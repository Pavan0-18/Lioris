"use client";
import React from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function ResetPasswordPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const token = searchParams.get("token") || "";

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const password = data.get("password") as string;
    const confirm = data.get("confirm") as string;

    if (password !== confirm) {
      toast.error("Passwords do not match");
      return;
    }

    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });
      if (!res.ok) throw new Error();
      toast.success("Security password modified! Redirecting...");
      router.push("/login");
    } catch {
      toast.error("Token is invalid or has expired.");
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-bold text-slate-100">Choose New Password</h2>
        <p className="text-xs text-slate-400">Update your workspace credentials.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="space-y-1.5">
          <Label className="text-slate-200">New Password</Label>
          <Input name="password" type="password" className="bg-slate-800 border-slate-700" required />
        </div>
        <div className="space-y-1.5">
          <Label className="text-slate-200">Confirm New Password</Label>
          <Input name="confirm" type="password" className="bg-slate-800 border-slate-700" required />
        </div>
        <Button type="submit" className="w-full bg-teal-500 text-slate-950 font-bold">
          Save New Password
        </Button>
      </form>
    </div>
  );
}

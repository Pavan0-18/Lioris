"use client";
import React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { WorkingHoursEditor, WorkingHourRow } from "@/components/settings/working-hours-editor";
import { toast } from "sonner";

export default function SetupPage() {
  const router = useRouter();
  const [step, setStep] = React.useState<1 | 2 | 3 | 4>(1);
  const [logoUrl, setLogoUrl] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const [workingHours, setWorkingHours] = React.useState<WorkingHourRow[]>(
    Array.from({ length: 7 }, (_, i) => ({
      dayOfWeek: i,
      openTime: "09:00",
      closeTime: "18:00",
      isClosed: i === 0 // Sunday closed
    }))
  );

  const handleStep1 = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = data.get("name") as string;
    const phone = data.get("phone") as string;

    try {
      const res = await fetch("/api/tenant/setup/business", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone, logoUrl }),
      });
      if (!res.ok) throw new Error();
      toast.success("Business details saved!");
      setStep(2);
    } catch {
      toast.error("Failed to save business profile.");
    }
  };

  const handleStep2 = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const branchName = data.get("branchName") as string;
    const address = data.get("address") as string;
    const city = data.get("city") as string;

    try {
      const res = await fetch("/api/tenant/branches", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: branchName, address, city, state: "State", country: "IN", isHQ: true }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error);

      const branchId = json.data.id;

      // Save Working hours
      await fetch(`/api/tenant/branches/${branchId}/hours`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(workingHours),
      });

      toast.success("Branch and working hours registered!");
      setStep(3);
    } catch (err: any) {
      toast.error(err.message || "Failed to setup branch.");
    }
  };

  const handleStep3 = async () => {
    try {
      // Create a sample service category
      const resCat = await fetch("/api/tenant/service-categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "Hair Styling" }),
      });
      const catJson = await resCat.json();
      const categoryId = catJson.data.id;

      // Create a sample service
      await fetch("/api/tenant/services", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: "Standard Haircut",
          categoryId,
          duration: 30,
          price: 25.00,
          taxable: true,
          description: "Precision haircut and style"
        }),
      });

      toast.success("Services catalog pre-filled!");
      setStep(4);
    } catch {
      toast.error("Failed to pre-fill services.");
    }
  };

  const handleStep4 = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const taxLabel = data.get("taxLabel") as string;
    const taxRate = Number(data.get("taxRate"));
    const taxId = data.get("taxId") as string;

    setSubmitting(true);
    try {
      await fetch("/api/tenant/setup/tax", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taxLabel, taxRate, taxId }),
      });

      await fetch("/api/tenant/setup/complete", { method: "PATCH" });

      toast.success("Onboarding configurations completed!");
      router.push("/dashboard");
    } catch {
      toast.error("Failed to complete onboarding.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <Card className="w-full max-w-lg shadow-lg">
        <CardHeader>
          <CardTitle>Welcome! Setup Your Workspace</CardTitle>
          <CardDescription>Step {step} of 4</CardDescription>
        </CardHeader>
        <CardContent>
          {step === 1 && (
            <form onSubmit={handleStep1} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Salon Business Name</Label>
                <Input name="name" required placeholder="Elegance Hair Salon" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Contact</Label>
                <Input name="phone" placeholder="+91 98765 43210" />
              </div>
              <Button type="submit" className="w-full">Save and Continue</Button>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={handleStep2} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="branchName">Headquarters Branch Name</Label>
                <Input name="branchName" required defaultValue="Main HQ" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Street Address</Label>
                <Input name="address" required placeholder="123 Luxury Road" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input name="city" required placeholder="Mumbai" />
                </div>
              </div>
              <WorkingHoursEditor value={workingHours} onChange={setWorkingHours} />
              <Button type="submit" className="w-full">Create Branch</Button>
            </form>
          )}

          {step === 3 && (
            <div className="space-y-4 text-center">
              <p className="text-sm text-muted-foreground">
                We will automatically populate your workspace with a <strong>Hair Styling</strong> service category and a <strong>Standard Haircut</strong> service ($25.00) to get you started immediately.
              </p>
              <Button onClick={handleStep3} className="w-full">Pre-fill and Continue</Button>
            </div>
          )}

          {step === 4 && (
            <form onSubmit={handleStep4} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="taxLabel">Tax Label</Label>
                  <Input name="taxLabel" defaultValue="GST" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="taxRate">Tax Rate (%)</Label>
                  <Input name="taxRate" type="number" defaultValue="18" required />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="taxId">Tax Registration ID (Tax ID / GSTIN)</Label>
                <Input name="taxId" placeholder="e.g. 27AAAAA1111A1Z1" />
              </div>
              <Button type="submit" disabled={submitting} className="w-full">
                {submitting ? "Finishing Setup..." : "Complete Setup & Launch"}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

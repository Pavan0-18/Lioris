"use client";
import React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { toast } from "sonner";
import { signIn } from "next-auth/react";
import Link from "next/link";

const COUNTRIES = [
  { code: "IN", label: "🇮🇳 India" },
  { code: "US", label: "🇺🇸 United States" },
  { code: "GB", label: "🇬🇧 United Kingdom" },
  { code: "AE", label: "🇦🇪 United Arab Emirates" },
  { code: "SG", label: "🇸🇬 Singapore" },
  { code: "AU", label: "🇦🇺 Australia" },
  { code: "CA", label: "🇨🇦 Canada" },
];

export default function SignupPage() {
  const router = useRouter();
  const [submitting, setSubmitting] = React.useState(false);

  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm({
    defaultValues: {
      salonName: "",
      name: "",
      email: "",
      password: "",
      phone: "",
      country: "IN"
    }
  });

  const countryVal = watch("country");

  const onSubmit = async (data: any) => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error);

      toast.success("Salon account registered! Authenticating...");

      // Automatically sign in
      await signIn("credentials", {
        redirect: false,
        email: data.email,
        password: data.password,
        type: "tenant"
      });

      router.push("/dashboard/setup");
    } catch (err: any) {
      toast.error(err.message || "Failed to register account.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-bold text-slate-100">Create Salon Workspace</h2>
        <p className="text-xs text-slate-400">Launch your salon management system in 30 seconds.</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
        <div className="space-y-1">
          <Label className="text-xs text-slate-200">Salon Name</Label>
          <Input
            type="text"
            {...register("salonName")}
            placeholder="e.g. Elegance Salon & Spa"
            className="bg-slate-800 border-slate-700 text-slate-100 focus-visible:ring-teal-400 h-8 text-xs"
            required
          />
        </div>

        <div className="space-y-1">
          <Label className="text-xs text-slate-200">Owner Full Name</Label>
          <Input
            type="text"
            {...register("name")}
            placeholder="e.g. Marie Antoinette"
            className="bg-slate-800 border-slate-700 text-slate-100 focus-visible:ring-teal-400 h-8 text-xs"
            required
          />
        </div>

        <div className="space-y-1">
          <Label className="text-xs text-slate-200">Business Email</Label>
          <Input
            type="email"
            {...register("email")}
            placeholder="owner@salonsaas.com"
            className="bg-slate-800 border-slate-700 text-slate-100 focus-visible:ring-teal-400 h-8 text-xs"
            required
          />
        </div>

        <div className="space-y-1">
          <Label className="text-xs text-slate-200">Password</Label>
          <Input
            type="password"
            {...register("password")}
            placeholder="Min 8 characters"
            className="bg-slate-800 border-slate-700 text-slate-100 focus-visible:ring-teal-400 h-8 text-xs"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label className="text-xs text-slate-200">Phone</Label>
            <Input
              type="text"
              {...register("phone")}
              placeholder="e.g. 9876543210"
              className="bg-slate-800 border-slate-700 text-slate-100 focus-visible:ring-teal-400 h-8 text-xs"
            />
          </div>

          <div className="space-y-1">
            <Label className="text-xs text-slate-200">Country</Label>
            <Select value={countryVal} onValueChange={(val) => setValue("country", val)}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-slate-100 h-8 text-xs focus-visible:ring-teal-400">
                <SelectValue placeholder="Country" />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800 text-slate-100">
                {COUNTRIES.map((c) => (
                  <SelectItem key={c.code} value={c.code}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button type="submit" disabled={submitting} className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold h-9 mt-2 text-xs">
          {submitting ? "Launching Workspace..." : "Register & Sign In"}
        </Button>
      </form>

      <div className="text-center pt-2 border-t border-slate-800">
        <p className="text-xs text-slate-400">
          Already have a salon workspace?{" "}
          <Link href="/login" className="text-teal-400 font-semibold hover:underline">Log In</Link>
        </p>
      </div>
    </div>
  );
}

"use client";
import React from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession();
  const router = useRouter();

  React.useEffect(() => {
    if (status === "authenticated") {
      if (session?.user?.role === "SUPER_ADMIN") {
        router.replace("/superadmin/dashboard");
      } else {
        router.replace("/dashboard");
      }
    }
  }, [session, status, router]);

  if (status === "loading") {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-950 text-slate-100">
        <p className="text-sm font-semibold tracking-wider">LOADING WORKSPACE...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-6">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold tracking-wider bg-gradient-to-r from-teal-400 to-indigo-400 bg-clip-text text-transparent">
            SALON SAAS PLATFORM
          </h1>
          <p className="text-xs text-slate-400 mt-2">Next-generation multi-tenant beauty ecosystem</p>
        </div>
        <Card className="p-6 bg-slate-900 border-slate-800 text-slate-100 shadow-xl">
          {children}
        </Card>
      </div>
    </div>
  );
}
